package com.navvora

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import coil3.ImageLoader
import coil3.PlatformContext
import coil3.SingletonImageLoader
import coil3.disk.DiskCache
import coil3.memory.MemoryCache
import coil3.network.okhttp.OkHttpNetworkFetcherFactory
import coil3.request.bitmapConfig
import coil3.request.crossfade
import com.navvora.app.plugin.PluginRepositoryService
import com.navvora.core.network.DohDns
import com.navvora.core.registry.PluginRegistry
import com.navvora.core.util.AppSessionManager
import com.navvora.data.preferences.PreferencesRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import okio.Path.Companion.toOkioPath

class NavvoraApp : Application(), SingletonImageLoader.Factory {
    override fun onCreate() {
        super.onCreate()
        val prefs = getSharedPreferences("navvora_session", Context.MODE_PRIVATE)
        val lastIndex = prefs.getInt("launch_session_index", 0)
        val nextIndex = lastIndex + 1
        prefs.edit().putInt("launch_session_index", nextIndex).apply()
        AppSessionManager.initialize(nextIndex)

        // Initialize 50MB HTTP disk cache and connection pool
        DohDns.initHttpCache(cacheDir)
        com.navvora.ui.player.sequential.SequentialStreamManager.cleanOrphanedCache(this)

        // Synchronously initialize JsPluginStorage, AddonRepository, and P2P engine instances
        com.navvora.core.js.JsPluginStorage.getInstance(this)
        com.navvora.core.addons.AddonRepository.getInstance(this)
        com.navvora.core.p2p.P2pStreamingEngine.initialize(this)
        com.navvora.core.p2p.P2pSettingsRepository.initialize(this)
        com.navvora.core.browser.HeadlessWebResolver.getInstance(this)

        // Initialize plugins, prefetch DNS, and restore default selected provider across restarts
        CoroutineScope(Dispatchers.IO).launch {
            try {
                com.navvora.core.js.JsPluginStorage.getInstance(this@NavvoraApp).initialize()
                com.navvora.core.addons.AddonRepository.getInstance(this@NavvoraApp).initialize()
            } catch (_: Exception) {}

            // DNS pre-fetch for critical media & metadata hosts
            DohDns.DEFAULT.prefetch(
                "navvora-vault.sehgalvansh716.workers.dev",
                "api.themoviedb.org",
                "image.tmdb.org",
                "graphql.anilist.co"
            )

            try {
                val prefsRepo = PreferencesRepository.getInstance(this@NavvoraApp)
                launch {
                    kotlinx.coroutines.flow.combine(
                        prefsRepo.debridEnabled,
                        prefsRepo.activeDebridProvider,
                        prefsRepo.realDebridApiKey,
                        prefsRepo.allDebridApiKey,
                        prefsRepo.torBoxApiKey
                    ) { enabled, provider, rdKey, adKey, tbKey ->
                        if (!enabled) {
                            com.navvora.core.debrid.DebridManager.getInstance().setActiveProviders(emptyList())
                            return@combine
                        }
                        val pType = com.navvora.core.debrid.DebridProviderType.fromId(provider)
                        val key = when (pType) {
                            com.navvora.core.debrid.DebridProviderType.REAL_DEBRID -> rdKey
                            com.navvora.core.debrid.DebridProviderType.ALL_DEBRID -> adKey
                            com.navvora.core.debrid.DebridProviderType.TORBOX -> tbKey
                            com.navvora.core.debrid.DebridProviderType.NONE -> ""
                        }
                        if (pType != com.navvora.core.debrid.DebridProviderType.NONE && key.isNotBlank()) {
                            com.navvora.core.debrid.DebridManager.getInstance().setActiveProviders(
                                listOf(com.navvora.core.debrid.DebridManager.ActiveDebridProvider(pType, true))
                            )
                        } else {
                            com.navvora.core.debrid.DebridManager.getInstance().setActiveProviders(emptyList())
                        }
                    }.collect { }
                }
            } catch (_: Exception) {}

            try {
                val savedProvider = PreferencesRepository.getInstance(this@NavvoraApp).activeProvider.first()
                if (savedProvider.isNotBlank()) {
                    PluginRegistry.Default.setActivePlugin(savedProvider)
                }
            } catch (_: Exception) {}

            try {
                PluginRepositoryService.getInstance(this@NavvoraApp).initializePlugins()
            } catch (_: Exception) {}

            try {
                val prefsRepo = PreferencesRepository.getInstance(this@NavvoraApp)
                val savedProvider = prefsRepo.activeProvider.first()
                if (savedProvider.isNotBlank() && PluginRegistry.Default.getPlugin(savedProvider) != null) {
                    PluginRegistry.Default.setActivePlugin(savedProvider)
                } else {
                    val firstPublic = PluginRepositoryService.getInstance(this@NavvoraApp)
                        .getInstalledPublicPlugins()
                        .firstOrNull { it.isEnabled }
                    if (firstPublic != null) {
                        PluginRegistry.Default.setActivePlugin(firstPublic.name)
                        prefsRepo.setActiveProvider(firstPublic.name)
                    }
                }
            } catch (_: Exception) {}
        }
    }

    override fun newImageLoader(context: PlatformContext): ImageLoader {
        return ImageLoader.Builder(context)
            .components {
                add(
                    OkHttpNetworkFetcherFactory(
                        callFactory = { DohDns.sharedBaseClient }
                    )
                )
            }
            .memoryCache {
                MemoryCache.Builder()
                    .maxSizePercent(context, 0.25)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("image_cache").toOkioPath())
                    .maxSizeBytes(250L * 1024 * 1024)
                    .build()
            }
            .bitmapConfig(Bitmap.Config.HARDWARE)
            .crossfade(220)
            .build()
    }
}
