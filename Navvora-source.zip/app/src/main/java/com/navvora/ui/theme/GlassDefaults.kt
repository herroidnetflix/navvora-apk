package com.navvora.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Shared styling constants for frosted-glass surfaces (FloatingNavbar and Hero "More Details" pill).
 */
object GlassDefaults {
    val BlurRadius: Dp = 24.dp
    const val TintAlpha: Float = 0.12f
    val TintColor: Color = Color.White.copy(alpha = TintAlpha)
    const val NoiseFactor: Float = 0.045f

    val BorderBrush: Brush = Brush.verticalGradient(
        listOf(
            Color.White.copy(alpha = 0.55f),
            Color(0xFF5CC8FF).copy(alpha = 0.22f),
            Color(0xFFB07CFF).copy(alpha = 0.14f)
        )
    )

    val NavbarFallbackColor: Color = Color(0xCC121B36)
    val PillFallbackColor: Color = Color.White.copy(alpha = 0.16f)
}
