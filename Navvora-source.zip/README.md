# Navvora

Personal-use Android app (Kotlin + Jetpack Compose), reskinned with a liquid-glass UI.
Based on the open-source Euthopiar project; no media is hosted by the app.

## Build the APK (no Android Studio needed)
1. Push this folder to your own GitHub repo.
2. Open the **Actions** tab, run **Navvora Staging CI** (push to `develop`) or push a tag like `v1.0.0` for the release workflow.
3. Download the APK from the run's Artifacts (or the Release page).

Local: `./gradlew assembleDebug` -> `app/build/outputs/apk/debug/`.

Set `GITHUB_OWNER` / `GITHUB_REPO` in `AppUpdateManager.kt` to your repo if you want in-app update checks.
