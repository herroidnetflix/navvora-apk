package com.navvora.core.plugin

typealias UniversalPlugin = com.navvora.core.model.UniversalPlugin
